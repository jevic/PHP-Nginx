#!/bin/sh
php -r "echo(str_replace('-dev','',PHP_VERSION));"
