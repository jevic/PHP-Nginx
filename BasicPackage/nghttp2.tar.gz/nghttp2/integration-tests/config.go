package nghttp2

const (
	buildDir = ".."
	sourceDir = ".."
)
