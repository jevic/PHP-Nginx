.. include:: ../doc/sources/tutorial-hpack.rst

deflate.c
---------

.. literalinclude:: ../examples/deflate.c
